<?php
include '../include/dbconnect.php';

$usernameErr = $emailErr = $passwordErr = $rePasswordErr = $phoneErr = $dobErr = "";
$username = $email = $password = $re_password = $phone = $dob = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $re_password = $_POST['re-entry'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];


    if (empty(trim($username))) {
        $usernameErr = "Please enter username.";
    } else {
        if (!preg_match("/^[a-zA-Z0-9 ]*$/", $username)) {
            $usernameErr = "Special character is not allowed!";
        }
    }

    if (empty(trim($email))) {
        $emailErr = "Please enter email address.";
    } else {
        $email = trim($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format.";
        }
    }

    if (empty(trim($password))) {
        $passwordErr = "Please enter a password.";
    } else {
        $password = trim($password);
        if (strlen($password) < 8) {
            $passwordErr = "Passwords must be at least 8 characters long.";
        } else if (preg_match("/^\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[^\w\s])\S*$/", $password)) {
            $passwordErr = "Passwords must contain at least 1 number, 1 uppercase letter, and 1 lowercase letter.";
        }
    }

    if (empty(trim($re_password))) {
        $rePasswordErr = "Please confirm password.";
    } else {
        $confirmPassword = trim($re_password);
        if ($password != $re_password) {
            $rePasswordErr = "Passwords do not match.";
        }
    }

    if (empty(trim($phone))) {
        $phoneErr = "Please enter phone number.";
    } else {
        $phone = trim($phone);
        if (strlen($phone) < 10) {
            $phoneErr = "Phone number must be at least 10 digits long (excluding -).";
        } else if (preg_match("/^01[0-9][-]?([0-9]{8})$/", $phone)) {
            $phoneErr = "Phone number should contain only numbers and the special character (-).";
        }
    }

    if (empty(trim($dob))) {
        $dobErr = "Please enter date of birth.";
    } else {
        $dob = trim($dob);
        $date = DateTime::createFromFormat('Y-m-d', $dob);
        
        if (!$date || $date->format('Y-m-d') !== $dob) {
            $dobErr = "Please enter a valid date of birth in the format YYYY-MM-DD.";
        } else {
            $dobYear = $date->format('Y');
            $currentYear = date('Y');
            $age = $currentYear - $dobYear;
            if ($age > 100) {
                $dobErr = "Your date of birth cannot be more than 100 years ago.";
            }
        }
    }
    

    if (empty($usernameErr) && empty($emailErr) && empty($passwordErr) && empty($rePasswordErr)&& empty($phoneErr)&& empty($dobErr)) {
        $check_client_query = "SELECT * FROM client WHERE client_name=?";
        $stmt = $conn->prepare($check_client_query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result_client = $stmt->get_result();

        if ($result_client->num_rows > 0) {
            $usernameErr = "Username already exists. Please choose a different username.";
        } else {
            $insert_query = "INSERT INTO client (client_name,client_password,gender,client_email,client_phone,birth_date) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insert_query);
            $stmt->bind_param("ssssss", $username,$password,$gender, $email,$phone,$dob);

            if ($stmt->execute()) {
                header("Location: admin_client.php");
                exit();
            } else {
                echo "Error: " . $stmt->error;
            }

            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="css/add_admin.css">
    <link rel="stylesheet" href="css/phone_add_admin.css">

</head>
<body>
    <?php include 'admin_panel.php'; ?>
    <div id="title">
        <a href="admin_client.php" title="Go Back "><span class="material-symbols-outlined">undo</span></a>
    </div>
    <h4>ADD CLIENT DETAILS</h4>
    <form  method="POST">
        <div>
            <label for="username">Username</label><br>
            <input type="text" name="username" id="username" value="<?php echo $username ?>">
        </div>
        <div>
            <span class="error"><?php echo $usernameErr; ?></span>
        </div>       
        <div>
            <label for="gender">Gender</label><br>
            <input type="radio" name="gender" id="gender" value="M" checked>Male
            <input type="radio" name="gender" id="gender" value="F">Female
        </div>
        <div>
            <label for="password">Password</label><br>
            <input type="password" name="password" id="password" value="<?php echo $password ?>">
        </div>
        <div>
            <span class="error"><?php echo $passwordErr; ?></span>
        </div>
        <div>
            <label for="re-entry">Re-enter Password</label><br>
            <input type="password" name="re-entry" id="re-entry" value="<?php echo $re_password ?>">
        </div>
        <div>
            <span class="error"><?php echo $rePasswordErr; ?></span>
        </div>
        <div>
            <label for="email">Email</label><br>
            <input type="email" name="email" id="email"value="<?php echo $email ?>">
        </div>
        <div>
            <span class="error"><?php echo $emailErr; ?></span>
        </div>
        <div>
            <label for="phone">Phone Number</label><br>
            <input type="tel" name="phone" id="phone" value="<?php echo $phone ?>">
        </div>
        <div>
            <span class="error"><?php echo $phoneErr; ?></span>
        </div>
        <div>
            <label for="dob">Birth Date</label><br>
            <input type="date" name="dob" id="dob" value="<?php echo $dob ?>">
        </div>
        <div>
            <span class="error"><?php echo $dobErr; ?></span>
        </div>
        <button type="submit">Add</button>
    </form>
</body>
</html>
