<?php
include 'admin_panel.php';
include '../include/dbconnect.php';
$photo_edit = '';
$nameErr = $fileErr = $artistErr = $dateErr = "";
$title_edit = $artist_edit = $released_edit = $file_edit = "";

if (isset($_GET['title'])) {
    $title = $_GET['title'];

    $sql = "SELECT image, title, artist, released_date, song_file FROM song WHERE title = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $title);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $photo_edit = $row["image"];
        $title_edit = $row["title"];
        $artist_edit = $row["artist"];
        $released_edit = $row["released_date"];
        $file_edit = $row["song_file"];
    } else {
        echo "Song not found.";
        exit;
    }

    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $song_title = $_POST['song_title'];
    $song_artist = $_POST['song_artist'];
    $song_link = $_POST['song_link'];
    $released = $_POST['released'];

    if (empty(trim($song_artist))) {
        $artistErr = "Please enter artist name.";
    } else {
        if (!preg_match("/^[a-zA-Z\s'-]+$/", $song_artist)) {
            $artistErr = "Only alphabetic characters, spaces, apostrophes, and hyphens are allowed for the artist name.";
        }
    }

    if (empty(trim($song_title))) {
        $nameErr = "Please enter song name.";
    } else {
        if (!preg_match("/^[a-zA-Z\s'-]+$/", $song_title)) {
            $nameErr = "Only alphabetic characters, spaces, apostrophes, and hyphens are allowed for the song name.";
        }
    }

    if (empty(trim($song_link))) {
        $fileErr = "Please enter song file or link.";
    }

    if (empty(trim($released))) {
        $dateErr = "Please enter release date.";
    } else {
        $rel_date = trim($released);
        $date = DateTime::createFromFormat('Y-m-d', $rel_date);
        
        if (!$date || $date->format('Y-m-d') !== $rel_date) {
            $dateErr = "Please enter a valid date in the format YYYY-MM-DD.";
        } 
    }

    if (isset($_FILES['song_photo']) && $_FILES['song_photo']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = "song_image/";
        $uploaded_file = $upload_dir . basename($_FILES['song_photo']['name']);

        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        if (move_uploaded_file($_FILES['song_photo']['tmp_name'], $uploaded_file)) {
            $up_photo = $uploaded_file;
        } else {
            echo "Error uploading file.";
            echo "Destination: $uploaded_file";
        }
    } else {
        $up_photo = $photo_edit;
    }

    if (empty($nameErr) && empty($fileErr) && empty($dateErr) && empty($artistErr)) {

        $update_query = "UPDATE song SET image = ?, title = ?, artist = ?, released_date = ?, song_file = ? WHERE title = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("ssssss", $up_photo, $song_title, $song_artist, $released, $song_link, $title);
    
        if ($stmt->execute()) {
            echo '<script>window.location.href = "admin_song.php";</script>';
    
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    
        $stmt->close();
        }

}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<meta charset="UTF-8">
<link rel="stylesheet" href="css/song_edit.css">
<link rel="stylesheet" href="css/phone_song_edit.css">

</head>
<body>
    <div id="title">
        <a href="admin_song.php" title="goback "><span class="material-symbols-outlined"><span class="material-symbols-outlined">undo</span></a>
    </div>
    <h4>EDIT SONG DETAILS</h4>
<form  method="post" enctype="multipart/form-data">
    <div>
        <label for="song_photo">SONG PHOTO</label><br>
        <input type="file" name="song_photo" id="song_photo" value="">
    </div>
    <div>
        <label for="song_title">SONG TITLE</label><br>
        <input type="text" name="song_title" id="song_title" value="<?php echo $title_edit; ?>" >
    </div>
    <div>
        <span class="error"><?php echo $nameErr; ?></span>
    </div>
    <div>
        <label for="song_artist">SONG ARTIST</label><br>
        <input type="text" name="song_artist" id="song_artist" value="<?php echo $artist_edit; ?>">
    </div>
    <div>
        <span class="error"><?php echo $artistErr; ?></span>
    </div>
    <div>
        <label for="released">RELEASED DATE</label><br>
        <input type="date" name="released" id="released" value="<?php echo $released_edit; ?>">
    </div>
    <div>
        <span class="error"><?php echo $dateErr; ?></span>
    </div>
    <div>
        <label for="song_link">SONG LINK</label><br>
        <input type="text" name="song_link" id="song_link" value="<?php echo $file_edit; ?>">
    </div>
    <div>
        <span class="error"><?php echo $fileErr; ?></span>
    </div>
    <button type="submit">UPDATE</button>
</form>
<div class="vertical-line"></div>
<h4 id="poster_display">SONG POSTER</h4>
<img src="<?php echo $photo_edit; ?>" class="display" height="250" width="250">
</body>
</html>
