<script>
    window.onload = toggleSpecifyOwner;
</script>
<?php 
include '../include/dbconnect.php';
$validErr=$nameErr=$discountErr=$ownerErr="";
$voucher_name=$owner="";


function getAllClientNames($conn) {
    $client_names = [];
    $sql = "SELECT client_name FROM client";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $client_names[] = $row['client_name'];
        }
    }

    return $client_names;
}

function generateVoucherCode($length = 8) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $voucherCode = '';
    $max = strlen($characters) - 1;
    for ($i = 0; $i < $length; $i++) {
        $voucherCode .= $characters[mt_rand(0, $max)];
    }
    return $voucherCode;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $voucher_name = $_POST['voucher_name'];
    $discount = $_POST['discount'];
    $valid = $_POST['valid'];
    $specifyOwner = isset($_POST['specify_owner_radio']) && $_POST['specify_owner_radio'] === 'yes';

    if ($specifyOwner) {
        $owner = $_POST['owner'];
        if (empty(trim($owner))) {
            $ownerErr = "Please enter the owner's name.";
        }
    }

    if (empty(trim($voucher_name))) {
        $nameErr = "Please enter voucher name.";
    } else {
        if (!preg_match("/^[a-zA-Z0-9 ]*$/", $voucher_name)) {
            $nameErr = "Special character is not allowed!";
        }
    }
    if (empty(trim($valid))) {
        $validErr = "Please enter Expiry date for voucher.";
    } else {
        $valid = trim($valid);
        $currentDate = date('Y-m-d');
        
        if ($valid < $currentDate) {
            $validErr = "Expiry date cannot be less than today's date.";
        } else {
            $date = DateTime::createFromFormat('Y-m-d', $valid);
            
            if (!$date || $date->format('Y-m-d') !== $valid) {
                $validErr = "Please enter a valid date in the format YYYY-MM-DD.";
            }
        }
    }

    if (empty(trim($discount))) {
        $discountErr = "Please enter discount.";
    } else {
        if ($discount >100) {
            $discountErr = "Discount more than 100 is not allowed!";
        }
    }

    if (empty($validErr) && empty($nameErr) && empty($discountErr) && empty($ownerErr)) {
        if ($specifyOwner) {
            $insert_query = "INSERT INTO voucher (voucher_id, voucher_name, discount, valid_date, owner) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insert_query);
            $voucherCode = generateVoucherCode();
            $stmt->bind_param("ssiss", $voucherCode, $voucher_name, $discount, $valid, $owner);
            $stmt->execute();
            $stmt->close();
        } else {
            $client_names = getAllClientNames($conn);
            foreach ($client_names as $client_name) {
                $insert_query = "INSERT INTO voucher (voucher_id, voucher_name, discount, valid_date, owner) VALUES (?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($insert_query);
                $voucherCode = generateVoucherCode();
                $stmt->bind_param("ssiss", $voucherCode, $voucher_name, $discount, $valid, $client_name);
                $stmt->execute();
                $stmt->close();
            }
        }
        header("Location: voucher.php");
        exit();    
    }
}

$sql2 = "SELECT * FROM client";
$result2 = $conn->query($sql2);
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link rel="stylesheet" href="css/add_voucher.css">
<link rel="stylesheet" href="css/phone_add_admin.css">
</head>
<body>
<?php include 'admin_panel.php'; ?>
<div id="title">
    <a href="voucher.php" title="Go Back "><span class="material-symbols-outlined">undo</span></a>
</div>
<h4>ADD VOUCHER DETAILS</h4>
<form action="add_voucher.php" method="POST" enctype="multipart/form-data">
    <div>
        <label for="voucher_name">VOUCHER NAME</label><br>
        <input type="text" name="voucher_name" id="voucher_name" value="<?php echo $voucher_name?>">            
    </div>
    <div>
        <span class="error"><?php echo $nameErr; ?></span>
    </div>
    <div>
        <label>TO WHOM?</label><br>
        <input type="radio" name="specify_owner_radio" id="specify_owner_radio" value="yes" onclick="toggleSpecifyOwner()" > SPECIFY OWNER
        <input type="radio" name="specify_owner_radio" value="no" checked> All CLIENTS
    </div>
    <script>
        document.getElementById('specify_owner_radio').addEventListener('change', toggleSpecifyOwner);
        document.querySelector('input[name="specify_owner_radio"][value="no"]').addEventListener('change', toggleSpecifyOwner);

        function toggleSpecifyOwner() {
            var specifyOwnerRadio = document.getElementById('specify_owner_radio');
            var ownerInput = document.getElementById('owner_input');

            if (specifyOwnerRadio.checked) {
                ownerInput.style.display = 'block';
            } else {
                ownerInput.style.display = 'none';
            }
        }
    </script>
    <div id="owner_input" style="display: none;">
        <label for="owner">OWNER</label><br>
        <select name="owner" id="owner" style="text-align: center;">
        <?php 
            if ($result2->num_rows > 0) {
                while ($row2 = $result2->fetch_assoc()) {
                    $name=$row2["client_name"];
                    echo"   
                        <option value='$name'>$name</option>";              
                }
            }
        ?>  
        </select>
        <div>
            <span class="error"><?php echo $ownerErr; ?></span>
        </div>
    </div>
    <div>
        <label for="discount">DISCOUNT(%)</label><br>
        <input type="number" name="discount" id="discount" max=100 value="<?php echo $discount?>" >
    </div>
    <div>
        <span class="error"><?php echo $discountErr; ?></span>
    </div>
    <div>
        <label for="valid">VALID DATE</label><br>
        <input type="date" name="valid" id="valid" value="<?php echo $valid?>" >
    </div>
    <div>
        <span class="error"><?php echo $validErr; ?></span>
    </div>
    <button type="submit" style="margin-top: 50px;">Add</button>
</form>
</body>
</html>
