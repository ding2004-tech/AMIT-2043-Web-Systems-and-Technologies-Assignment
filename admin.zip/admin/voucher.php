<?php
include 'admin_panel.php';
include '../include/dbconnect.php';

$message = "";

$search = '';
if (isset($_POST['search'])) {
    $search = $_POST['search'];
}

$sort_column = isset($_POST['sort_column']) ? $_POST['sort_column'] : 'voucher_id';
$sort_order = isset($_POST['sort_order']) && $_POST['sort_order'] == 'DESC' ? 'DESC' : 'ASC';

if (isset($_POST['delete_row'])) {
    $id_delete = $_POST['delete_row'];

    $sql = "DELETE FROM voucher WHERE voucher_id = ?";
    $stmt_client = $conn->prepare($sql);
    $stmt_client->bind_param("s", $id_delete);
    $stmt_client->execute();

    $stmt_client->close();
}

if (empty($search)) {
    $sql = "SELECT * FROM voucher ORDER BY $sort_column $sort_order";
} else {
    $sql = "SELECT * FROM voucher WHERE voucher_name LIKE '%$search%' OR owner LIKE '%$search%' ORDER BY $sort_column $sort_order";
}
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="css/voucher.css">
    <link rel="stylesheet" href="css/phone_admin.css">
</head>
<body>
<div class="client_table">
    <h4>Voucher</h4>
    <a href="add_voucher.php" class="add">ADD</a>
</div>

<form class = "search" action="" method="POST" style="position:absolute;top:3%;left:43%;">
    <input type="text" name="search" value="<?php echo $search; ?>" placeholder="VOUCHER NAME OR OWNER" style="width:450px;padding-left: 50px;padding-right:50px;padding-top:10px;padding-bottom:10px;border-radius:25px;">
    <button style="position:relative;right:40px;border:none;background-color:transparent;cursor:pointer;" type="submit"><i class="fa-solid fa-magnifying-glass" style="font-size: 20px;z-index:1000000000;"></i></button>
</form>

<form class = "sort" action="" method="POST" style="position:absolute;top:4%;left:80%;">
    <select name="sort_column" id="sort_column" style="padding:5px;background-color:transparent;border:2px solid black;font-weight:bold;cursor:pointer;">
        <option value="voucher_id" <?php if ($sort_column == 'voucher_id') echo 'selected'; ?>>ID</option>
        <option value="voucher_name" <?php if ($sort_column == 'voucher_name') echo 'selected'; ?>>Voucher Name</option>
        <option value="discount" <?php if ($sort_column == 'discount') echo 'selected'; ?>>Discount</option>
        <option value="valid_date" <?php if ($sort_column == 'valid_date') echo 'selected'; ?>>Valid Date</option>
        <option value="owner" <?php if ($sort_column == 'owner') echo 'selected'; ?>>Owner</option>
    </select>
    <button type="submit" name="sort_order" title="ASCENDING" style="border:none;background-color:transparent;cursor:pointer;">
        <i class="fas fa-sort-amount-down-alt" style="font-size: 24px;"></i>
    </button>
    <button type="submit" name="sort_order" value="DESC" title="DESCENDING" style="border:none;background-color:transparent;cursor:pointer;">
        <i class="fas fa-sort-amount-up" style="font-size: 24px;"></i>
    </button>
</form>

<table>
    <tr style="background-color: black; color:white">
        <td>ID</td>
        <td>VOUCHER NAME</td>
        <td>DISCOUNT</td>
        <td>VALID DATE</td>
        <td>OWNER</td>
        <td>ACTION</td>
    </tr>
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $id = $row["voucher_id"];
            $name = $row["voucher_name"];
            $valid_date = $row["valid_date"];
            $owner = $row["owner"];
            $discount = $row["discount"];
            echo "<tr>
                    <td>$id</td>
                    <td>$name</td>
                    <td>$discount</td>
                    <td>$valid_date</td>
                    <td>$owner</td>
                    <td>
                        <div class='action-container' onsubmit='return confirmDelete()'>
                            <form  method='POST'>                      
                                <button type='submit' name='delete_row' id='delete_row' value='$id' style='background-color:red;'>DELETE</button>
                            </form>
                        </div>
                    </td>
                </tr>";
        }
        echo "</table>";
    } else {
        $message = "0 records";
    }

    echo "<div class='message'>$message</div>"; 
    ?>
</table>

<script>
    function confirmDelete() {
        return confirm("Are you sure you want to delete this voucher?");
    }
</script>
</body>
</html>