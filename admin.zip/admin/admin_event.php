<?php
include 'admin_panel.php';
include '../include/dbconnect.php';
$message = "";

if (isset($_POST['delete_row'])) {
    $name_to_delete = $_POST['delete_row'];
    $sql = "DELETE FROM events WHERE event_name = ?";
    $stmt_client = $conn->prepare($sql);
    $stmt_client->bind_param("s", $name_to_delete);
    $stmt_client->execute();
    $stmt_client->close();
}

$search = '';
if (isset($_POST['search'])) {
    $search = $_POST['search'];
}

$sort_column = isset($_POST['sort_column']) ? $_POST['sort_column'] : 'event_name';
$sort_order = isset($_POST['sort_order']) && $_POST['sort_order'] == 'DESC' ? 'DESC' : 'ASC';

if (empty($search)) {
    $sql = "SELECT * FROM events ORDER BY $sort_column $sort_order";
} else {
    $sql = "SELECT * FROM events WHERE event_name LIKE '%$search%' OR event_place LIKE '%$search%' OR event_nation LIKE '%$search%' ORDER BY $sort_column $sort_order";
}

$result = $conn->query($sql);
?>
<html>
<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <script src="https://kit.fontawesome.com/d25b499fc2.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/admin_event.css">
    <link rel="stylesheet" href="css/phone_admin.css">
</head>
<body>
    <div class="client_table">
        <h4>EVENT ACTIVITY</h4>
        <a href="add_event.php" class="add">ADD</a>
    </div>

    <form class = "search" action="" method="POST" style="position:absolute;top:3%;left:43%;">
        <input type="text" name="search" value="<?php echo $search; ?>" placeholder="EVENT NAME OR EVENT COUNTRY OR VENUE" style="width:450px;padding-left: 50px;padding-right:50px;padding-top:10px;padding-bottom:10px;border-radius:25px;">
        <button style="position:relative;right:40px;border:none;background-color:transparent;cursor:pointer;" type="submit"><i class="fa-solid fa-magnifying-glass" style="font-size: 20px;z-index:1000000000;"></i></button>
    </form>

    <form class = "sort" action="" method="POST" style="position:absolute;top:4%;left:80%;">
        <select name="sort_column" id="sort_column" style="padding:5px;background-color:transparent;border:2px solid black;font-weight:bold;cursor:pointer;">
            <option value="event_name" <?php if ($sort_column == 'event_name') echo 'selected'; ?>>Event Name</option>
            <option value="event_date" <?php if ($sort_column == 'event_date') echo 'selected'; ?>>Event Date</option>
            <option value="event_time" <?php if ($sort_column == 'event_time') echo 'selected'; ?>>Event Time</option>
            <option value="event_price" <?php if ($sort_column == 'event_price') echo 'selected'; ?>>Event Price</option>
            <option value="event_place" <?php if ($sort_column == 'event_place') echo 'selected'; ?>>Event Venue</option>
            <option value="venue_seat" <?php if ($sort_column == 'venue_seat') echo 'selected'; ?>>Seat Count</option>
        </select>
        <button type="submit" name="sort_order" title="ASCENDING" style="border:none;background-color:transparent;cursor:pointer;">
            <i class="fas fa-sort-amount-down-alt" style="font-size: 24px;"></i>
        </button>
        <button  type="submit" name="sort_order" value="DESC" title="DESCENDING"  style="border:none;background-color:transparent;cursor:pointer;">
            <i class="fas fa-sort-amount-up"  style="font-size: 24px;"></i>
        </button>
    </form>

    <table>
        <tr style="background-color: black; color:white;">
            <td>POSTER</td>
            <td>NAME</td>
            <td>DATE AND TIME</td>
            <td>PRICE</td>
            <td>VENUE</td>
            <td>SEAT</td>
            <td>ACTION</td>
        </tr>
        <?php if ($result->num_rows > 0) { ?>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <?php
                $poster = $row["event_poster"];
                $name = $row["event_name"];
                $date = $row["event_date"];
                $price = $row["event_price"];
                $time = $row["event_time"];
                $venue = $row["event_place"];
                $nation = $row["event_nation"];
                $seat = $row["venue_seat"];
                $id = $row["event_id"];
                ?>
                <tr>
                    <td><img src='<?php echo $poster; ?>' width='90' height='90'></td>
                    <td><?php echo $name; ?></td>
                    <td><?php echo $date . "\t" . $time; ?></td>
                    <td><?php echo $price; ?></td>
                    <td><?php echo $venue . "," . $nation; ?></td>
                    <td><?php echo $seat; ?></td>
                    <td>
                        <div class='action-container'><a href='event_edit.php?id=<?php echo $id; ?>'>EDIT</a></div>
                        <div class='action-container' onsubmit='return confirmDelete()'>
                            <form action='admin_event.php' method='POST'>
                                <button type='submit' name='delete_row' id='delete_row' value='<?php echo $name; ?>' style='background-color:red;'>DELETE</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php } ?>
        <?php } else { ?>
            <?php $message = "0 records"; ?>
        <?php } ?>
    </table>
    <div class='message'><?php echo $message; ?></div>
    <script>
        function confirmDelete() {
            return confirm("Are you sure you want to delete this record?");
        }
    </script>
</body>
</html>