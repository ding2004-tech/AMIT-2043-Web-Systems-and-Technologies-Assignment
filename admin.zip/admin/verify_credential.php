<?php
session_start();
include '../include/dbconnect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login_user']) && isset($_POST['login_pw'])) {
    $login_user = $_POST['login_user'];
    $login_pw = $_POST['login_pw'];

    $client_sql = "SELECT * FROM client WHERE client_name = ? AND client_password = ?";
    $client_stmt = $conn->prepare($client_sql);
    $client_stmt->bind_param("ss", $login_user, $login_pw);
    $client_stmt->execute();
    $client_result = $client_stmt->get_result();

    $admin_sql = "SELECT * FROM administrator WHERE admin_name = ? AND admin_password = ?";
    $admin_stmt = $conn->prepare($admin_sql);
    $admin_stmt->bind_param("ss", $login_user, $login_pw);
    $admin_stmt->execute();
    $admin_result = $admin_stmt->get_result();

    if ($client_result->num_rows > 0) {
        $client_data = $client_result->fetch_assoc();
        $_SESSION['login_user'] = $login_user;
        $_SESSION['login_type'] = 'user';
        $_SESSION['email'] = $client_data['client_email'];
        $_SESSION['photo'] = $client_data['client_photo'];
        header('Location: ../index.php');
    }
    elseif ($admin_result->num_rows > 0) {
        $admin_data = $admin_result->fetch_assoc();
        $_SESSION['role_position'] = $admin_data['role_position'];
        $_SESSION['login_user'] = $login_user;       
         $_SESSION['login_type'] = 'admin';
        $_SESSION['photo'] = $admin_data['admin_photo'];
        header('Location: admin.php');
    }
    else {
        $_SESSION['error'] = "Invalid username or password";
        $_SESSION['login_user_value'] = $login_user; 
        $_SESSION['login_pw_value'] = $login_pw; 
        $_SESSION['error'] = "Invalid user or password!!";
        header('Location: ../login.php');
    }
    $client_stmt->close();
    $admin_stmt->close();
}

$conn->close();
?>
