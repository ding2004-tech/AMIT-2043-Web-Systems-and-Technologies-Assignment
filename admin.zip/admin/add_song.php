<?php 
include '../include/dbconnect.php';

$nameErr = $fileErr = $artistErr = $dateErr = "";
$name = $file = $artist = $rel_date= "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['song_name'];
    $file = $_POST['file'];
    $artist = $_POST['artist'];
    $rel_date = $_POST['released_date'];

    // File upload handling
    if(isset($_FILES['img']) && $_FILES['img']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = "song_image/"; 
        $uploaded_file = $upload_dir . basename($_FILES['img']['name']); 
    
        if(!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true); 
        }
    
        if(move_uploaded_file($_FILES['img']['tmp_name'], $uploaded_file)) {
            $up_photo = $uploaded_file;
        } else {
            echo "Error uploading file.";
            echo "Destination: $uploaded_file"; 
        }
    }

    // Validation
    if (empty(trim($artist))) {
        $artistErr = "Please enter artist name.";
    } else {
        if (!preg_match("/^[a-zA-Z ]*$/", $artist)) {
            $artistErr = "Special character and digit are not allowed!";
        }
    }

    if (empty(trim($name))) {
        $nameErr = "Please enter song name.";
    } else {
        if (!preg_match("/^[a-zA-Z0-9 ]*$/", $name)) {
            $nameErr = "Special character is not allowed!";
        }
    }

    if (empty(trim($file))) {
        $fileErr = "Please enter song file or link.";
    }

    if (empty(trim($rel_date))) {
        $dateErr = "Please enter released date.";
    } else {
        $rel_date = trim($rel_date);
        $date = DateTime::createFromFormat('Y-m-d', $rel_date);
        
        if (!$date || $date->format('Y-m-d') !== $rel_date) {
            $dateErr = "Please enter a valid released date in the format YYYY-MM-DD.";
        } 
    }

    if (empty($nameErr) && empty($fileErr) && empty($dateErr) && empty($artistErr)) {
        $insert_query = "INSERT INTO song (title, artist, image, released_date, song_file) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("sssss", $name, $artist, $up_photo, $rel_date, $file);
    
        if ($stmt->execute()) {
            header("Location: admin_song.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/add_song.css">
    <link rel="stylesheet" href="css/phone_add_admin.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<body>
    <?php include 'admin_panel.php'; ?>
    <div id="title">
        <a href="admin_song.php" title="Go Back "><span class="material-symbols-outlined">undo</span></a>
        <h4>ADD SONG DETAILS</h4>
    </div>
    <form action="add_song.php" method="POST" enctype="multipart/form-data">
        <div>
            <label for="song_name">SONG TITLE</label><br>
            <input type="text" name="song_name" value="<?php echo $name; ?>"  id="username" >
        </div>
        <div>
            <span class="error"><?php echo $nameErr; ?></span>
        </div>
        <div>
            <label for="artist">ARTIST</label><br>
            <input type="text" name="artist" id="password" value="<?php echo $artist; ?>">
        </div>
        <div>
            <span class="error"><?php echo $artistErr; ?></span>
        </div>
        <div>
            <label for="released_date">RELEASED DATE</label><br>
            <input type="date" name="released_date" id="DATE" value="<?php echo $rel_date; ?>">
        </div>
        <div>
            <span class="error"><?php echo $dateErr; ?></span>
        </div>
        <div>
            <label for="file">SONG FILE</label><br>
            <input type="text" name="file" id="file" <?php echo $file; ?>>
        </div>
        <div>
            <span class="error"><?php echo $fileErr; ?></span>
        </div>
        <div>
            <label for="img">SONG IMAGE</label><br>
            <input type="file" name="img" id="img" >
        </div>
        <button type="submit">Add</button>
    </form>
</body>
</html>
