<?php
    include 'admin_panel.php';
    include '../include/dbconnect.php';

    $message = ""; 

    $search = '';
    if (isset($_POST['search'])) {
        $search = $_POST['search'];
    }

    $sort_column = isset($_POST['sort_column']) ? $_POST['sort_column'] : 'name';
    $sort_order = isset($_POST['sort_order']) && $_POST['sort_order'] == 'DESC' ? 'DESC' : 'ASC';

    if (isset($_POST['delete_row'])) {
        $name_to_delete = $_POST['delete_row']; 
        $sql = "DELETE FROM history_image WHERE name = ?";
        $stmt_client = $conn->prepare($sql);
        $stmt_client->bind_param("s", $name_to_delete);
        $stmt_client->execute();

        $stmt_client->close();
    }

    if (empty($search)) {
        $sql = "SELECT * FROM history_image ORDER BY $sort_column $sort_order";
    } else {
        $sql = "SELECT * FROM history_image WHERE name LIKE '%$search%' OR concert_name LIKE '%$search%' ORDER BY $sort_column $sort_order";
    }
    $result = $conn->query($sql);

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="css/history_image.css">
        <link rel="stylesheet" href="css/phone_admin.css">
        <link rel="stylesheet" href="css/phone_history_image.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <script src="https://kit.fontawesome.com/d25b499fc2.js" crossorigin="anonymous"></script>    
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

    </head>
    <body>
        <div class="title-history">
            <h4>History Image</h4>
            <a href="add_history_image.php" class="add">ADD</a>
        </div>

        <form class = "search" action="" method="POST" style="position:absolute;top:3%;left:43%;">
            <input type="text" name="search" value="<?php echo $search; ?>" placeholder="ARTIST NAME OR CONCERT NAME" style="width:450px;padding-left: 50px;padding-right:50px;padding-top:10px;padding-bottom:10px;border-radius:25px;">
            <button style="position:relative;right:40px;border:none;background-color:transparent;cursor:pointer;" type="submit"><i class="fa-solid fa-magnifying-glass" style="font-size: 20px;z-index:1000000000;"></i></button>
        </form>

        <form class = "sort" action="" method="POST" style="position:absolute;top:4%;left:80%;">
            <select name="sort_column" id="sort_column" style="padding:5px;background-color:transparent;border:2px solid black;font-weight:bold;cursor:pointer;">
                <option value="name" <?php if ($sort_column == 'name') echo 'selected'; ?>>Name</option>
                <option value="concert_name" <?php if ($sort_column == 'concert_name') echo 'selected'; ?>>Concert Name</option>
            </select>
            <button type="submit" name="sort_order" title="ASCENDING" style="border:none;background-color:transparent;cursor:pointer;">
                <i class="fas fa-sort-amount-down-alt" style="font-size: 24px;"></i>
            </button>
            <button type="submit" name="sort_order" value="DESC" title="DESCENDING" style="border:none;background-color:transparent;cursor:pointer;">
                <i class="fas fa-sort-amount-up" style="font-size: 24px;"></i>
            </button>
        </form>

        <div class="card-container">

            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $name = $row["name"];
                    $concert_name = $row["concert_name"];
                    $photo = $row["photo"];
                    echo "<div class='card'>
                            <img src='$photo'>
                            <div class='name-tag'>
                            <h3>$name</h3>
                            <div class='action-container'><a title='Edit' href='history_edit.php?name=$name'><i class='fa-regular fa-pen-to-square'></i></a></div>
                                <div class='action-container'>
                                <form action='history_image.php' method='POST' onsubmit='return confirmDelete()'>                      
                                <button type='submit' value='$name'title='Delete' name='delete_row' id='delete_row'>
                                    <i class='fa-solid fa-trash' style='color:red;font-size:18px;'></i>
                                    </button>
                                </form>
                                </div>
                            </div>
                        </div>";
                }
            } 
            ?>
        </div>

        
        <script>
            function confirmDelete() {
                return confirm("Are you sure you want to delete this record?");
            }
        </script>
    </body>
    </html>