<?php
include 'admin_panel.php';
include '../include/dbconnect.php';
$message = "";

if (isset($_POST['delete_row'])) {
    $name_to_delete = $_POST['delete_row'];
    $sql_client = "DELETE FROM client WHERE client_name = ?";
    $stmt_client = $conn->prepare($sql_client);
    $stmt_client->bind_param("s", $name_to_delete);
    $stmt_client->execute();
    $stmt_client->close();
}

$search = '';
if (isset($_POST['search'])) {
    $search = $_POST['search'];
}

$sort_column = isset($_POST['sort_column']) ? $_POST['sort_column'] : 'client_name';
$sort_order = isset($_POST['sort_order']) && $_POST['sort_order'] == 'DESC' ? 'DESC' : 'ASC';

if (empty($search)) {
    $sql = "SELECT id, client_name, gender, client_password, client_phone, client_email, birth_date, reg_date FROM client ORDER BY $sort_column $sort_order";
} else {
    $sql = "SELECT id, client_name, gender, client_password, client_phone, client_email, birth_date, reg_date FROM client WHERE client_name LIKE '%$search%' OR client_email LIKE '%$search%' ORDER BY $sort_column $sort_order";
}

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="css/admin_client.css">
    <link rel="stylesheet" href="css/phone_admin_client.css">
</head>
<body>
    <div class="client_table">
        <h4>CLIENT PROFILE</h4>
        <a href="add_client.php" class="add">ADD</a>
    </div>

    <form class = "search" action="" method="POST" style="position:absolute;top:3%;left:43%;">
    <input type="text" name="search" value="<?php echo $search; ?>" placeholder="NAME OR EMAIL" style="width:450px;padding-left: 50px;padding-right:50px;padding-top:10px;padding-bottom:10px;border-radius:25px;">
        <button style="position:relative;right:40px;border:none;background-color:transparent;cursor:pointer;" type="submit"><i class="fa-solid fa-magnifying-glass" style="font-size: 20px;z-index:1000000000;"></i></button>
    </form>

    <form class = "sort" action="" method="POST" style="position:absolute;top:4%;left:80%;">
        <select name="sort_column" id="sort_column" style="padding:5px;background-color:transparent;border:2px solid black;font-weight:bold;cursor:pointer;">
            <option value="client_name" <?php if ($sort_column == 'client_name') echo 'selected'; ?>>Name</option>
            <option value="gender" <?php if ($sort_column == 'gender') echo 'selected'; ?>>Gender</option>
            <option value="client_phone" <?php if ($sort_column == 'client_phone') echo 'selected'; ?>>Phone Number</option>
            <option value="client_email" <?php if ($sort_column == 'client_email') echo 'selected'; ?>>Email</option>
            <option value="birth_date" <?php if ($sort_column == 'birth_date') echo 'selected'; ?>>Birth Date</option>
            <option value="reg_date" <?php if ($sort_column == 'reg_date') echo 'selected'; ?>>Registration Date</option>
        </select>
        <button type="submit" name="sort_order" title="ASCENDING" style="border:none;background-color:transparent;cursor:pointer;">
            <i class="fas fa-sort-amount-down-alt" style="font-size: 24px;"></i>
        </button>
        <button  type="submit" name="sort_order" value="DESC" title="DESCENDING"  style="border:none;background-color:transparent;cursor:pointer;">
            <i class="fas fa-sort-amount-up"  style="font-size: 24px;"></i>
        </button>
    </form>

    <div class = "table-container">
        <table>
            <tr style="background-color: black; color:white">
                <td>NAME</td>
                <td>SEX</td>
                <td>PASSWORD</td>
                <td>PHONE NUMBER</td>
                <td>EMAIL</td>
                <td>BIRTH DATE</td>
                <td>JOIN</td>
                <td>ACTION</td>
            </tr>
            <?php if ($result->num_rows > 0) { ?>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <?php
                    $gender = $row["gender"];
                    $name = $row["client_name"];
                    $password = $row["client_password"];
                    $birthdate = $row["birth_date"];
                    $phone = $row["client_phone"];
                    $email = $row["client_email"];
                    $reg = $row["reg_date"];
                    ?>
                    <tr>
                        <td><?php echo $name; ?></td>
                        <td><?php echo $gender; ?></td>
                        <td><?php echo $password; ?></td>
                        <td><?php echo $phone; ?></td>
                        <td><?php echo $email; ?></td>
                        <td><?php echo $birthdate; ?></td>
                        <td><?php echo $reg; ?></td>
                        <td>
                            <div class='action-container'><a href='client_edit.php?name=<?php echo $name; ?>'>EDIT</a></div>
                            <div class='action-container' onsubmit='return confirmDelete()'>
                                <form action='admin_client.php' method='POST'>
                                    <button type='submit' name='delete_row' id='delete_row' value='<?php echo $name; ?>' style='background-color:red;'>DELETE</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php } ?>
            <?php } else { ?>
                <?php $message = "0 records"; ?>
            <?php } ?>
        </table>
    </div>

    <div class='message'><?php echo $message; ?></div>
    <script>
        function confirmDelete() {
            return confirm("Are you sure you want to delete this record?");
        }
    </script>
</body>
</html>