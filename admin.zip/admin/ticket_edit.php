<?php
include 'admin_panel.php';
include '../include/dbconnect.php';

if(isset($_GET['ticket_id'])) {
    $id = $_GET['ticket_id'];

    $sql = "SELECT b.ticket_id, b.event_id, e.event_name, e.event_date, e.event_nation, e.event_time, e.event_place, b.seat_number, b.purchase_time, b.buyer 
    FROM booking b 
    JOIN events e ON b.event_id = e.event_id WHERE ticket_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $name_edit = $row["event_name"];
        $buyer_edit = $row["buyer"];
        $seat_edit = $row["seat_number"];
    } else {
        echo "Client not found.";
        exit;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $seatNumber = $_POST["seatNumber"];
    $owner = $_POST["owner"];


    $update_query = "UPDATE booking SET event_id=?, seat_number=?,buyer=?, WHERE ticket_id=?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("iisi", $name, $seatNumber,$owner, $id);

    if ($stmt->execute()) {
        echo "Update successful";
        header('Location: admin_ticket.php'); 
        exit();
    }
    
    $stmt->close(); 
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/ticket_edit.css">
    <link rel="stylesheet" href="css/phone_admin_edit.css"> 
</head>
<body>
    <div id="title">
        <a href="admin.php" title="go back"><span class="material-symbols-outlined">undo</span></a>
        <h4>EDIT TICKET DETAILS</h4>
    </div>
    <form method="post">
        <div>
            <label for="username">EVENT NAME</label><br>
            <input type="text" name="name" id="name" value="<?php echo $name_edit; ?>" pattern="[A-Za-z 0-9]+">
        </div>
        <div>
            <label for="seatNumber">SEAT NUMBER</label><br>
            <input type="text" name="seatNumber" id="seatNumber" value="<?php echo $seat_edit; ?>" pattern="[0-9]+" disabled>
        </div>
        <div>
            <label for="owner">OWNER</label><br>
            <input type="text" name="owner" id="owner" value="<?php echo $buyer_edit; ?>" pattern="[A-Za-z 0-9]+">
        </div>
        <button type="submit">UPDATE</button>
    </form>
</body>
</html>
