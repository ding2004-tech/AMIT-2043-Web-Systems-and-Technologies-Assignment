<?php
include '../include/dbconnect.php';
$seatErr = $seat_number = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['event_id'];
    $seat_number = $_POST['seat_number'];
    $owner = $_POST['owner'];

    if (empty(trim($seat_number))) {
        $seatErr = "Please enter seat number.";
    } else {
        if (!preg_match("/^[0-9]*$/", $seat_number)) {
            $seatErr = "Only allow digit number only!";
        } else {
            $check_seat_query = "SELECT COUNT(*) AS seat_count
                                 FROM booking b
                                 JOIN events e ON b.event_id = e.event_id
                                 WHERE e.event_id = ? AND b.seat_number = ?";
            $stmt = $conn->prepare($check_seat_query);
            $stmt->bind_param("ii", $id, $seat_number);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();

            if ($row['seat_count'] > 0) {
                $seatErr = "The seat number is already booked for this event.";
            }

            $sql3 = "SELECT e.venue_seat - COUNT(b.seat_number) AS available_seats
                     FROM events e
                     LEFT JOIN booking b ON e.event_id = b.event_id
                     WHERE e.event_id = ?
                     GROUP BY e.event_id;";
            $stmt = $conn->prepare($sql3);
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();

            if ($seat_number > $row['available_seats']) {
                $seatErr = "The entered seat number exceeds the available seats for this event.";
            }
        }
    }

    if (empty($seatErr)) {
        $insert_query = "INSERT INTO booking (event_id, seat_number, buyer) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("iis", $id, $seat_number, $owner);

        if ($stmt->execute()) {
            header("Location: admin_ticket.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

$sql = "SELECT event_name, event_id FROM events";
$result = $conn->query($sql);
$sql2 = "SELECT * FROM client";
$result2 = $conn->query($sql2);
?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link rel="stylesheet" href="css/add_ticket.css">
<link rel="stylesheet" href="css/phone_add_admin.css">
</head>
<body>
    <?php include 'admin_panel.php'; ?>
    <div id="title">
        <a href="admin_ticket.php" title="Go Back "><span class="material-symbols-outlined">undo</span></a>
    </div>
    <h4>ADD TICKET DETAILS</h4>
    <form action="add_ticket.php" method="POST" enctype="multipart/form-data">
        <div>
            <label for="event_poster">EVENT NAME</label><br>
            <select name="event_id" id="event_id">
            <?php 
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $event_name=$row["event_name"];
                        $id=$row["event_id"];
                        echo"   
                            <option value='$id'>$event_name</option>               
                        ";
                    }
                    echo"</select>";
                }
            ?>
        </div>
        <div>
            <label for="seat_number">SEAT NUMBER</label><br>
            <input type="number" name="seat_number" id="seat_number" value="<?php echo $seat_number?>" >
        </div>
        <div>
            <span class="error"><?php echo $seatErr; ?></span>
        </div> 
        <div>
            <label for="owner">OWNER</label><br>
            <select name="owner" id="owner" style="text-align: center;">
            <?php 
                if ($result2->num_rows > 0) {
                    while ($row2 = $result2->fetch_assoc()) {
                        $name=$row2["client_name"];
                        echo"   
                            <option value='$name'>$name</option>               
                        ";
                    }
                    echo"</select>";
                }
            ?>        
        </div>
        <button type="submit" style="margin-top: 50px;">Add</button>
    </form>
</body>
</html>
