<?php 
include '../include/dbconnect.php';

$concertErr = $artistErr = "";
$art_name= $concert_name ="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $art_name = $_POST['art_name'];
    $concert_name = $_POST['concert_name'];


    if(isset($_FILES['concert_img']) && $_FILES['concert_img']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = "past_image//"; 
        $uploaded_file = $upload_dir . basename($_FILES['concert_img']['name']); 
    
        if(!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true); 
        }
    
        if(move_uploaded_file($_FILES['concert_img']['tmp_name'], $uploaded_file)) {
            $up_photo = $uploaded_file;
        } else {
            echo "Error uploading file.";
            echo "Destination: $uploaded_file"; 
        }
    }

    if (empty(trim($art_name))) {
        $artistErr = "Please enter artist name.";
    } else {
        if (!preg_match("/^[a-zA-Z ]*$/", $art_name)) {
            $artistErr = "Special character and digit is not allowed!";
        }
    }

    if (empty(trim($concert_name))) {
        $concertErr = "Please enter concert name.";
    } else {
        if (!preg_match("/^[a-zA-Z0-9 ]*$/", $concert_name)) {
            $concertErr = "Special character is not allowed!";
        }
    }


    if (empty($artistErr) && empty($concertErr)) {
        $insert_query = "INSERT INTO  history_image(name, concert_name, photo) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("sss", $art_name, $concert_name, $up_photo);
    
        if ($stmt->execute()) {
            header("Location: history_image.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    
        $stmt->close();
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/add_song.css">
    <link rel="stylesheet" href="css/phone_add_admin.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>
<body>
    <?php include 'admin_panel.php'; ?>
    <div id="title">
        <a href="history_image.php" title="Go Back "><span class="material-symbols-outlined">undo</span></a>
        <h4>ADD HISTORY IMAGE DETAILS</h4>
    </div>
    <form action="add_history_image.php" method="POST" enctype="multipart/form-data">
        <div>
            <label for="art_name">Artist Name</label><br>
            <input type="text" name="art_name" value="<?php echo $art_name; ?>"  id="username" >
        </div>
        <div>
            <span class="error"><?php echo $artistErr; ?></span>
        </div>
        <div>
            <label for="concert_name">Concert Name</label><br>
            <input type="text" name="concert_name" id="concert_name" value="<?php echo $concert_name; ?>">
        </div>
        <div>
            <span class="error"><?php echo $concertErr; ?></span>
        </div>
        <div>
            <label for="concert_img">Concert Photo</label><br>
            <input type="file" name="concert_img" id="concert_img" >
        </div>
        <button type="submit">Add</button>
    </form>
</body>
</html>
