<?php
include 'admin_panel.php'; 
include '../include/dbconnect.php';

if (!isset($_SESSION['login_user'])) {
    header('Location:login.php');
    exit();
}


$user = $_SESSION['login_user'];

$usernameErr = $phoneErr = $passwordErr = $oldpasswordErr = $newpasswordErr = $rePasswordErr = "";

$sql = "SELECT admin_photo, admin_name, admin_password, admin_email, admin_phone FROM administrator WHERE admin_name = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $username = $row["admin_name"];
        $password = $row["admin_password"];
        $email = $row["admin_email"];
        $phone = $row["admin_phone"];
        $photo = $row["admin_photo"];
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = "uploads/";
        $uploaded_file = $upload_dir . basename($_FILES['photo']['name']); 

        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true); 
        }

        if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploaded_file)) {
            $photo = $uploaded_file;
            $update_photo_query = "UPDATE administrator SET admin_photo=? WHERE admin_name=?";
            $update_photo_stmt = $conn->prepare($update_photo_query);
            $update_photo_stmt->bind_param("ss", $photo, $user);
            $update_photo_stmt->execute();
            $_SESSION['photo'] = $photo;
        } else {
            echo "Error uploading file.";
        }
    }

    if (isset($_POST['up_username'])) {
        $up_username = $_POST['up_username'];
        $update_username_query = "UPDATE administrator SET admin_name=? WHERE admin_name=?";
        $update_username_stmt = $conn->prepare($update_username_query);
        $update_username_stmt->bind_param("ss", $up_username, $user);
        $update_username_stmt->execute();
        $username = $up_username;
    }

    if (isset($_POST['newpassword']) && isset($_POST['oldpassword']) && isset($_POST['re-entry'])) {
        $newpassword = $_POST['newpassword'];
        $oldpassword = $_POST['oldpassword'];
        $re_entered_password = $_POST['re-entry'];
        if(empty($oldpassword)){
            $oldpasswordErr="Please enter your old password!!!";
        }        
        if ($newpassword == null) {
            $newpasswordErr = 'Please enter New Password.';
        } else if (strlen($newpassword) < 8 || strlen($newpassword) > 15) {
            $newpasswordErr = 'New Password must be between 8 to 15 characters.';
        } else if (!preg_match('/^\w+$/', $newpassword)) {
            $newpasswordErr = 'New Password must contain only alphabets, digits, and underscores.';
        }

        if ($re_entered_password == null) {
            $rePasswordErr = 'Please enter Re-enter Password.';
        } else if ($re_entered_password != $newpassword) {
            $rePasswordErr = 'Re-enter Password must match the new password.';
        }

        if ($newpasswordErr == "" && $rePasswordErr == "") {
            if ($oldpassword === $password) {
                $update_password_query = "UPDATE administrator SET admin_password=? WHERE admin_name=?";
                $update_password_stmt = $conn->prepare($update_password_query);
                $update_password_stmt->bind_param("ss", $newpassword, $user);
                if ($update_password_stmt->execute()) {
                    echo "Password updated successfully.";
                } else {
                    echo "Error updating password: " . $update_password_stmt->error;
                }
            } else {
                $oldpasswordErr = "Old password is incorrect";
            }
        }
    }

    if (isset($_POST['up_phone'])) {
        $up_phone = $_POST['up_phone'];
        if (!preg_match("/^01[0-9][-]?([0-9]{8})$/", $up_phone)) {
            $phoneErr= "Invalid phone number format";
        } else {
            $update_phone_query = "UPDATE administrator SET admin_phone=? WHERE admin_name=?";
            $update_phone_stmt = $conn->prepare($update_phone_query);
            $update_phone_stmt->bind_param("ss", $up_phone, $user);
            $update_phone_stmt->execute();
            $phone = $up_phone;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Settings</title>
    <link rel="stylesheet" href="css/admin_setting.css">
    <link rel="stylesheet" href="css/phone_admin_setting.css">
</head>
<body>
    <h3 style="position: absolute;">SETTING</h3>
    <form action="admin_setting.php" method="POST" enctype="multipart/form-data">
        <div>
            <label for="username">USERNAME</label><br>
            <input type="text" name="up_username" id="username" value="<?php echo "$username"; ?>" disabled>
        </div>
        <div>
            <span class="error"><?php echo $usernameErr; ?></span>
        </div>
        <div>
            <label for="email">EMAIL</label><br>
            <input type="email" name="email" id="email" value="<?php echo "$email"; ?>" disabled>
        </div>
        <div>
            <label for="phone">PHONE NUMBER</label><br>
            <input type="tel" name="up_phone" id="phone" value="<?php echo "$phone"; ?>">
        </div>
        <div>
            <span class="error"><?php echo $phoneErr; ?></span>
        </div>
        <button type="submit">UPDATE DETAILS</button>
    </form>
    <form action="admin_setting.php" method="POST" enctype="multipart/form-data" style="margin-top: 290px;">
        <div>
            <label for="password">CURRENT PASSWORD</label><br>
            <input type="password" name="oldpassword" id="oldpassword">
        </div>
        <div>
            <span class="error"><?php echo $oldpasswordErr; ?></span>
        </div>
        <div>
            <label for="newpassword">NEW PASSWORD</label><br>
            <input type="password" name="newpassword" id="newpassword" >
        </div>
        <div>
            <span class="error"><?php echo $newpasswordErr; ?></span>
        </div>
        <div>
            <label for="re-entry">RE-ENTRY PASSWORD</label><br>
            <input type="password" name="re-entry" id="re-entry" >
        </div>
        <div>
            <span class="error"><?php echo $rePasswordErr; ?></span>
        </div>

        <button type="submit"  style="margin-bottom:100px;">CHANGE PASSWORD</button>
    </form>
    <div class="uploadPhoto">
        <form action="admin_setting.php" method="POST" enctype="multipart/form-data" >
            <div style="display: inline-block;">
                <label for="photo">UPLOAD PROFILE PHOTO</label><br>
                <input type="file" name="photo" id="photo">
            </div>
            <button type="submit">UPDATE</button>
        </form>
    </div>
    <div class="vertical-line"></div>
    <h4>PROFILE PHOTO</h4>
    <img src="<?php echo $photo; ?>" class="display" height="300" width="250">

    
</body>
</html>
