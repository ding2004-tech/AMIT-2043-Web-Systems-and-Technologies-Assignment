<?php
include 'admin_panel.php';
include '../include/dbconnect.php';
$message = "";

if (isset($_POST['delete_row'])) {
    $name_to_delete = $_POST['delete_row'];
    $sql_admin = "DELETE FROM administrator WHERE admin_name = ?";
    $stmt_admin = $conn->prepare($sql_admin);
    $stmt_admin->bind_param("s", $name_to_delete);
    if ($stmt_admin->execute()) {
        $message = "Admin record deleted successfully";
    } else {
        $message = "Error deleting admin record";
    }
    $stmt_admin->close();
}

$search = '';
if (isset($_POST['search'])) {
    $search = $_POST['search'];
}

$sort_column = isset($_POST['sort_column']) ? $_POST['sort_column'] : 'admin_name';
$sort_order = isset($_POST['sort_order']) && $_POST['sort_order'] == 'DESC' ? 'DESC' : 'ASC';

if (empty($search)) {
    $sql = "SELECT gender, admin_name, admin_password, admin_email, admin_phone, role_position FROM administrator ORDER BY $sort_column $sort_order";
} else {
    $sql = "SELECT gender, admin_name, admin_password, admin_email, admin_phone, role_position FROM administrator WHERE admin_name LIKE '%$search%' OR admin_email LIKE '%$search%' ORDER BY $sort_column $sort_order";
}

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Profile</title>
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/phone_admin.css">
</head>
<body>
    <div class="client_table">
        <h4>ADMIN PROFILE</h4>
        <a href="add_admin.php" class="add">ADD</a>
    </div>

    <form class = "search" action="" method="POST" style="position:absolute;top:3%;left:43%;">
        <input type="text" name="search" value="<?php echo $search; ?>" placeholder="NAME OR EMAIL" style="width:450px;padding-left: 50px;padding-right:50px;padding-top:10px;padding-bottom:10px;border-radius:25px;">
        <button style="position:relative;right:40px;border:none;background-color:transparent;cursor:pointer;" type="submit"><i class="fa-solid fa-magnifying-glass" style="font-size: 20px;z-index:1000000000;"></i></button>
    </form>

    <form class = "sort" action="" method="POST" style="position:absolute;top:4%;left:80%;">
        <select name="sort_column" id="sort_column" style="padding:5px;background-color:transparent;border:2px solid black;font-weight:bold;cursor:pointer;">
            <option value="admin_name" <?php if ($sort_column == 'admin_name') echo 'selected'; ?>>Name</option>
            <option value="gender" <?php if ($sort_column == 'gender') echo 'selected'; ?>>Gender</option>
            <option value="admin_phone" <?php if ($sort_column == 'admin_phone') echo 'selected'; ?>>Phone Number</option>
            <option value="admin_email" <?php if ($sort_column == 'admin_email') echo 'selected'; ?>>Email</option>
            <option value="role_position" <?php if ($sort_column == 'role_position') echo 'selected'; ?>>Role</option>
        </select>
        <button type="submit" name="sort_order" title="ASCENDING" style="border:none;background-color:transparent;cursor:pointer;">
            <i class="fas fa-sort-amount-down-alt" style="font-size: 24px;"></i>
        </button>
        <button type="submit" name="sort_order" value="DESC" title="DESCENDING" style="border:none;background-color:transparent;cursor:pointer;">
            <i class="fas fa-sort-amount-up" style="font-size: 24px;"></i>
        </button>
    </form>

    <table>
        <tr style="background-color: black; color:white">
            <td>NAME</td>
            <td>SEX</td>
            <td>PASSWORD</td>
            <td>PHONE NUMBER</td>
            <td>EMAIL</td>
            <td>ROLE</td>
            <td>ACTION</td>
        </tr>
        <?php if ($result->num_rows > 0) { ?>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <?php
                if ($row['admin_name'] == $_SESSION['login_user']) {
                    continue;
                }
                $role_position = $row["role_position"];
                $name = $row["admin_name"];
                $phone = $row["admin_phone"];
                $email = $row["admin_email"];
                $gender = $row["gender"];
                $password = $row["admin_password"];
                ?>
                <tr>
                    <td><?php echo $name; ?></td>
                    <td><?php echo $gender; ?></td>
                    <td><?php echo $password; ?></td>
                    <td><?php echo $phone; ?></td>
                    <td><?php echo $email; ?></td>
                    <td><?php echo $role_position; ?></td>
                    <td>
                        <div class='action-container'><a href='admin_edit.php?name=<?php echo $name; ?>'>EDIT</a></div>
                        <div class='action-container' onsubmit='return confirmDelete()'>
                            <form method='POST'>
                                <button type='submit' name='delete_row' id='delete_row' value='<?php echo $name; ?>' style='background-color:red;'>DELETE</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php } ?>
        <?php } else { ?>
            <?php $message = "0 records"; ?>
        <?php } ?>
    </table>
    <div class='message'><?php echo $message; ?></div>
    <script>
        function confirmDelete() {
            return confirm("Are you sure you want to delete this record?");
        }
    </script>
</body>
</html>