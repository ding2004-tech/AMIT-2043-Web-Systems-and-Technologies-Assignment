<?php
include 'admin_panel.php';
include '../include/dbconnect.php';

$message = "";

$search = '';
if (isset($_POST['search'])) {
    $search = $_POST['search'];
}

$sort_column = isset($_POST['sort_column']) ? $_POST['sort_column'] : 'ticket_id';
$sort_order = isset($_POST['sort_order']) && $_POST['sort_order'] == 'DESC' ? 'DESC' : 'ASC';

if (isset($_POST['delete_row'])) {
    $id_delete = $_POST['delete_row'];

    $sql = "DELETE FROM booking WHERE ticket_id = ?";
    $stmt_client = $conn->prepare($sql);
    $stmt_client->bind_param("i", $id_delete);
    $stmt_client->execute();

    $stmt_client->close();
}

if (empty($search)) {
    $sql = "SELECT b.ticket_id, b.event_id, e.event_name, e.event_date, e.event_nation, e.event_time, e.event_place, b.seat_number, b.purchase_time, b.buyer
            FROM booking b
            JOIN events e ON b.event_id = e.event_id
            ORDER BY $sort_column $sort_order";
} else {
    $sql = "SELECT b.ticket_id, b.event_id, e.event_name, e.event_date, e.event_nation, e.event_time, e.event_place, b.seat_number, b.purchase_time, b.buyer
            FROM booking b
            JOIN events e ON b.event_id = e.event_id
            WHERE b.buyer LIKE '%$search%' OR e.event_name LIKE '%$search%'
            ORDER BY $sort_column $sort_order";
}
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="css/admin_ticket.css">
    <link rel="stylesheet" href="css/phone_admin.css">
</head>
<body>
<div class="client_table">
    <h4>Ticket Booking</h4>
    <a href="add_ticket.php" class="add">ADD</a>
</div>

<form class = "search" action="" method="POST" style="position:absolute;top:3%;left:43%;">
    <input type="text" name="search" value="<?php echo $search; ?>" placeholder="BUYER OR EVENT NAME" style="width:450px;padding-left: 50px;padding-right:50px;padding-top:10px;padding-bottom:10px;border-radius:25px;">
    <button style="position:relative;right:40px;border:none;background-color:transparent;cursor:pointer;" type="submit"><i class="fa-solid fa-magnifying-glass" style="font-size: 20px;z-index:1000000000;"></i></button>
</form>

<form class = "sort" action="" method="POST" style="position:absolute;top:4%;left:80%;">
    <select name="sort_column" id="sort_column" style="padding:5px;background-color:transparent;border:2px solid black;font-weight:bold;cursor:pointer;">
        <option value="ticket_id" <?php if ($sort_column == 'ticket_id') echo 'selected'; ?>>Ticket ID</option>
        <option value="event_name" <?php if ($sort_column == 'event_name') echo 'selected'; ?>>Event Name</option>
        <option value="seat_number" <?php if ($sort_column == 'seat_number') echo 'selected'; ?>>Seat Number</option>
        <option value="buyer" <?php if ($sort_column == 'buyer') echo 'selected'; ?>>Buyer</option>
        <option value="purchase_time" <?php if ($sort_column == 'purchase_time') echo 'selected'; ?>>Purchase Time</option>
    </select>
    <button type="submit" name="sort_order" title="ASCENDING" style="border:none;background-color:transparent;cursor:pointer;">
        <i class="fas fa-sort-amount-down-alt" style="font-size: 24px;"></i>
    </button>
    <button type="submit" name="sort_order" value="DESC" title="DESCENDING" style="border:none;background-color:transparent;cursor:pointer;">
        <i class="fas fa-sort-amount-up" style="font-size: 24px;"></i>
    </button>
</form>

<table>
    <tr style="background-color: black; color:white">
        <td>ID</td>
        <td>EVENT NAME</td>
        <td>SEAT</td>
        <td>BUYER</td>
        <td>PURCHASE TIME</td>
        <td>ACTION</td>
    </tr>
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $id = $row["ticket_id"];
            $name = $row["event_name"];
            $seat = $row["seat_number"];
            $purchase = $row["purchase_time"];
            $buyer = $row["buyer"];
            echo "<tr>
                    <td>$id</td>
                    <td>$name</td>
                    <td>$seat</td>
                    <td>$buyer</td>
                    <td>$purchase</td>
                    <td>
                        <div class='action-container' onsubmit='return confirmDelete()'>
                            <form  method='POST'>                      
                                <button type='submit' name='delete_row' id='delete_row' value='$id' style='background-color:red;'>DELETE</button>
                            </form>
                        </div>
                    </td>
                </tr>";
        }
        echo "</table>";
    } else {
        $message = "0 records";
    }

    echo "<div class='message'>$message</div>"; 
    ?>
</table>

<script>
    function confirmDelete() {
        return confirm("Are you sure you want to delete this record?");
    }
</script>
</body>
</html>