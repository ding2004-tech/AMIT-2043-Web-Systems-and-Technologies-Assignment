<?php
include 'verify_credential.php';
include '../include/dbconnect.php';

if (!isset($_SESSION['login_type']) || $_SESSION['login_type'] !== 'admin') {
  header('location:../index.php');
  exit;
}

$admin_photo = isset($_SESSION['photo']) ? $_SESSION['photo'] : null;
$admin_name = isset($_SESSION['login_user']) ? $_SESSION['login_user'] : null;
$admin_role = isset($_SESSION['role_position']) ? $_SESSION['role_position'] : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon"  href="../MHS Logo.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
    <script src="https://kit.fontawesome.com/d25b499fc2.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
  <title>ADMINISTARTOR</title>
  <link rel="stylesheet" href="css/panel.css">
  <link rel="stylesheet" href="css/phone_admin_panel.css">
</head>
<body>
    <div class="sidebar">
      <div class="profile">
        <div class="user-img">
          <img src="<?php echo $admin_photo; ?>" alt="">
        </div>
        <div class="user-details">
          <p class="title"><?php echo "$admin_role"; ?></p>
          <p class="name"><?php echo "$admin_name"; ?></p>
        </div>
      </div>
      <div class="nav">
        <div class="menu">
          <p class="title">Dashboard</p>
          <ul>
            <li><a href="admin_ticket.php"><span class="text">Ticket Booking</span></a></li>
            <li><a href="admin_song.php"><span class="text">Song Database</span></a></li>
            <li><a href="admin_event.php"><span class="text">Event</span></a></li>
            <li><a href="history_image.php"><span class="text">History Image</span></a></li>
            <li><a href="voucher.php"><span class="text">Voucher</span></a></li>
          </ul>
        </div>
        <div class="menu">
          <p class="title">ACCOUNT CONTROL</p>
          <ul>
            <li><a href="admin_client.php"><span class="text">USER</span></a></li>
            <li><a href="admin.php"><span class="text">ADMIN</span></a></li>
          </ul>
        </div>
      </div>
      <div class="menu">
        <p class="title">Account Details</p>
        <ul>
          <li><a href="admin_setting.php"><span class="text">Setting</span></a></li>
          <li><a href="logout.php"><span class="text">Logout</span></a></li>
        </ul>
      </div>
    </div>

    <div class="navbar">

      <div class="profile">
        <div class="user-img">
          <img src="<?php echo $admin_photo; ?>" alt="">
        </div>
        <div class="user-details">
          <p class="title"><?php echo "$admin_role"; ?></p>
          <p class="name"><?php echo "$admin_name"; ?></p>
        </div>
      </div>

      <div class="nav">

        <div class="menu">
          <button class="dropbtn">
            <p>Dashboard</p>
            <i class="fa fa-caret-down"></i>
          </button>
          <ul class = "dropdown">
            <li><a href="admin_ticket.php"><span class="text">Ticket Booking</span></a></li>
            <li><a href="admin_song.php"><span class="text">Song Database</span></a></li>
            <li><a href="admin_event.php"><span class="text">Event</span></a></li>
            <li><a href="history_image.php"><span class="text">History Image</span></a></li>
            <li><a href="voucher.php"><span class="text">Voucher</span></a></li>
          </ul>
        </div>

        <div class="menu">
          <button class="dropbtn">
            <p>Account Control</p>
            <i class="fa fa-caret-down"></i>
          </button>
          <ul class = "dropdown">
            <li><a href="admin_client.php"><span class="text">USER</span></a></li>
            <li><a href="admin.php"><span class="text">ADMIN</span></a></li>
          </ul>
        </div>

        <div class="menu">
          <button class="dropbtn">
            <p>Account Details</p>
            <i class="fa fa-caret-down"></i>
          </button>
          <ul class = "dropdown">
            <li><a href="admin_setting.php"><span class="text">Setting</span></a></li>
            <li><a href="logout.php"><span class="text">Logout</span></a></li>
          </ul>
        </div>

      </div>
    </div>
      

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.js" integrity="sha512-8Z5++K1rB3U+USaLKG6oO8uWWBhdYsM3hmdirnOEWp8h2B1aOikj5zBzlXs8QOrvY9OxEnD2QDkbSKKpfqcIWw==" crossorigin="anonymous"></script>
  <script>
   $(".menu > ul > li").click(function (e) {
        $(this).siblings().removeClass("active");
        $(this).toggleClass("active");
        $(this).find("ul").slideToggle();
        $(this).siblings().find("ul").slideUp();
        $(this).siblings().find("ul").find("li").removeClass("active");
        });

        $(".menu-btn").click(function () {
        $(".sidebar").toggleClass("active");
    });
  </script>
</body>
</html>
