<?php
include '../include/dbconnect.php';
$message = "";

$search = '';
if (isset($_POST['search'])) {
    $search = $_POST['search'];
}

$sort_column = isset($_POST['sort_column']) ? $_POST['sort_column'] : 'title';
$sort_order = isset($_POST['sort_order']) && $_POST['sort_order'] == 'DESC' ? 'DESC' : 'ASC';

if (empty($search)) {
    $sql = "SELECT image, title, artist, released_date, song_file FROM song ORDER BY $sort_column $sort_order";
} else {
    $sql = "SELECT image, title, artist, released_date, song_file FROM song WHERE title LIKE '%$search%' OR artist LIKE '%$search%' ORDER BY $sort_column $sort_order";
}
$result = $conn->query($sql);

if (isset($_POST['delete_row'])) {
    $title = $_POST['delete_row'];

    $sql_song = "DELETE FROM song WHERE title = ?";
    $stmt_song = $conn->prepare($sql_song);
    $stmt_song->bind_param("s", $title);
    $stmt_song->execute();

    $stmt_song->close();

    header("Location: admin_song.php");
    exit();
}
?>
<html>
    <head>
        <link rel="stylesheet" href="css/admin_song.css">
        <link rel="stylesheet" href="css/phone_admin.css">
        <link rel="stylesheet" href="css/phone_admin_song.css">
    </head>
    <body>
        <?php include 'admin_panel.php'; ?>
        <div class="song_table">
            <h4>SONG LIST</h4>
            <a href="add_song.php" class="add">ADD</a>
        </div>

        <form class = "search" action="" method="POST" style="position:absolute;top:3%;left:43%;">
            <input type="text" name="search" value="<?php echo $search; ?>" placeholder="TITLE OR ARTIST" style="width:450px;padding-left: 50px;padding-right:50px;padding-top:10px;padding-bottom:10px;border-radius:25px;">
            <button style="position:relative;right:40px;border:none;background-color:transparent;cursor:pointer;" type="submit"><i class="fa-solid fa-magnifying-glass" style="font-size: 20px;z-index:1000000000;"></i></button>
        </form>

        <form class = "sort" action="" method="POST" style="position:absolute;top:4%;left:80%;">
            <select name="sort_column" id="sort_column" style="padding:5px;background-color:transparent;border:2px solid black;font-weight:bold;cursor:pointer;">
                <option value="title" <?php if ($sort_column == 'title') echo 'selected'; ?>>Title</option>
                <option value="artist" <?php if ($sort_column == 'artist') echo 'selected'; ?>>Artist</option>
                <option value="released_date" <?php if ($sort_column == 'released_date') echo 'selected'; ?>>Released Date</option>
            </select>
            <button type="submit" name="sort_order" title="ASCENDING" style="border:none;background-color:transparent;cursor:pointer;">
                <i class="fas fa-sort-amount-down-alt" style="font-size: 24px;"></i>
            </button>
            <button type="submit" name="sort_order" value="DESC" title="DESCENDING" style="border:none;background-color:transparent;cursor:pointer;">
                <i class="fas fa-sort-amount-up" style="font-size: 24px;"></i>
            </button>
        </form>

        <table>
            <tr style="background-color: black; color:white">
                <td>PHOTO</td>
                <td>TITLE</td>
                <td>ARTIST</td>
                <td>RELEASED DATE</td>
                <td>SONG FILE</td>
                <td>ACTION</td>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $photo = $row["image"];
                    $title = $row["title"];
                    $artist = $row["artist"];
                    $released_date = $row["released_date"];
                    $file = $row["song_file"];

                    echo "<tr>
                            <td><img src='$photo' width=70 height=70 ></td>
                            <td>$title</td>
                            <td>$artist</td>
                            <td>$released_date</td>
                            <td>$file</td>
                            <td>
                                <div class='action-container'><a href='song_edit.php?title=$title'>EDIT</a></div>
                                <div class='action-container' onsubmit='return confirmDelete()'>
                                    <form action='admin_song.php' method='POST'>                      
                                        <button type='submit' name='delete_row' id='delete_row' value='$title' style='background-color:red;'>DELETE</button>
                                    </form>
                                </div>
                            </td>
                        </tr>";
                }
                echo "</table>";
            } else {
                $message = "0 records";
            }
            echo "<div class='message'>$message</div>";
            ?>
        </table>
        <script>
            function confirmDelete() {
                return confirm("Are you sure you want to delete this ticket?");
            }
        </script>
    </body>
</html>