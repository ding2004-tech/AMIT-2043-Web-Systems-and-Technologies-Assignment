<?php
include 'admin_panel.php';
include '../include/dbconnect.php';

$usernameErr = $emailErr = $passwordErr = $rePasswordErr = $phoneErr  =$dobErr = "";
$user = $email = $password = $re_password = $phone  =$dob = "";


if(isset($_GET['name'])) {
    $name = $_GET['name'];

    $sql = "SELECT client_name, client_password, client_phone, client_email, birth_date, reg_date FROM client WHERE client_name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $name_edit = $row["client_name"];
        $password_edit = $row["client_password"];
        $birthdate_edit = $row["birth_date"];
        $phone_edit = $row["client_phone"];
        $email_edit = $row["client_email"];
    } else {
        echo "Client not found.";
        exit; 
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $sex = $_POST["sex"];
    $password = $_POST["password"];
    $dob = $_POST["birth_date"];
    $tel = $_POST["tel"];
    $email = $_POST["email"];

    if (empty(trim($email))) {
        $emailErr = "Please enter email address.";
    } else {
        $email = trim($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format.";
        }
    }

    if (empty(trim($tel))) {
        $phoneErr = "Please enter phone number.";
    } else {
        $tel = trim($tel);
        if (strlen($tel) < 10) {
            $phoneErr = "Phone number must be at least 10 digits long (excluding -).";
        } else if (preg_match("/^01[0-9][-]?([0-9]{8})$/", $tel)) {
            $phoneErr = "Phone number should contain only numbers and the special character (-).";
        }
    }

    if (empty(trim($password))) {
        $passwordErr = "Please enter a password.";
    } else {
        $password = trim($password);
        if (strlen($password) < 8) {
            $passwordErr = "Passwords must be at least 8 characters long.";
        } else if (preg_match("/^\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])(?=\S*[^\w\s])\S*$/", $password)) {
            $passwordErr = "Passwords must contain at least 1 number, 1 uppercase letter, and 1 lowercase letter.";
        }
    }

    if (empty(trim($username))) {
        $usernameErr = "Please enter username.";
    } else {
        if (!preg_match("/^[a-zA-Z0-9 ]*$/", $username)) {
            $usernameErr = "Special character is not allowed!";
        }
    }

    if (empty(trim($dob))) {
        $dobErr = "Please enter date of birth.";
    } else {
        $dob = trim($dob);
        $date = DateTime::createFromFormat('Y-m-d', $dob);
        
        if (!$date || $date->format('Y-m-d') !== $dob) {
            $dobErr = "Please enter a valid date of birth in the format YYYY-MM-DD.";
        } else {
            $dobYear = $date->format('Y');
            $currentYear = date('Y');
            $age = $currentYear - $dobYear;
            if ($age > 100) {
                $dobErr = "Your date of birth cannot be more than 100 years ago.";
            }
        }
    }
    

    if (empty($usernameErr) && empty($emailErr) && empty($passwordErr)&& empty($phoneErr) && empty($dobErr)) {
        $update_query = "UPDATE client SET client_name=?, gender=?,client_password=?, client_phone=?, client_email=?, birth_date=? WHERE client_name=?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("sssssss", $username, $sex,$password, $tel, $email, $dob, $name);
    
        if ($stmt->execute()) {
            ?><script> window.location.href = 'admin_client.php';</script>
            <?php exit();
        } else {
            echo "Error updating client details: " . $stmt->error;
        }
        
        $stmt->close(); 
    }


}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/client_edit.css">
    <link rel="stylesheet" href="css/phone_admin_edit.css">
</head>
<body>
    <div id="title">
        <a href="admin_client.php" title="goback "><span class="material-symbols-outlined"><span class="material-symbols-outlined">undo</span></a>
    </div>
    <h4>EDIT CLIENT DETAILS</h4>
    <form method="post">
        <div>
            <label for="username">USERNAME</label><br>
            <input type="text" name="username" id="username" value="<?php echo $name_edit; ?>" pattern="[A-Za-z 0-9]+">
        </div>
        <div>
            <span class="error"><?php echo $usernameErr; ?></span>
        </div>
        <div>
            <label for="sex">GENDER</label><br>
            <input type="radio" name="sex" id="gender" value="M" checked>Male
            <input type="radio" name="sex" id="gender" value="F">Female
        </div>
        <div>
            <label for="password">PASSWORD</label><br>
            <input type="password" name="password" id="password" value="<?php echo $password_edit; ?>" pattern="^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$">
        </div>
        <div>
            <span class="error"><?php echo $passwordErr; ?></span>
        </div> 
        <div>
            <label for="email">EMAIL</label><br>
            <input type="text" name="email" id="email" value="<?php echo $email_edit; ?>" pattern="^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$">
        </div>
        <div>
            <span class="error"><?php echo $emailErr; ?></span>
        </div>
        <div>
            <label for="tel">PHONE NUMBER</label><br>
            <input type="tel" name="tel" id="tel" value="<?php echo $phone_edit; ?>">
        </div>
        <div>
            <span class="error"><?php echo $phoneErr; ?></span>
        </div>
        <div>
            <label for="birth_date">BIRTH DATE</label><br>
            <input type="date" name="birth_date" id="birth_date" value="<?php echo $birthdate_edit; ?>">
        </div>
        <div>
            <span class="error"><?php echo $dobErr; ?></span>
        </div>
        <button type="submit">UPDATE</button>
    </form>
</body>
</html>
